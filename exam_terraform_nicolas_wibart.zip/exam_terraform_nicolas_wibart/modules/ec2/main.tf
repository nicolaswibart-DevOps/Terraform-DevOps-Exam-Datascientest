########################################
# Instance EC2 Wordpress
########################################

resource "aws_instance" "this" {
  ami                    = var.ami_id
  instance_type          = var.instance_type
  subnet_id              = var.subnet_id
  vpc_security_group_ids = [var.security_group_id]
  key_name               = var.ssh_key_name

  user_data = file(var.user_data_path)

  tags = {
    Name = "${var.project_name}-ec2-wp"
  }
}